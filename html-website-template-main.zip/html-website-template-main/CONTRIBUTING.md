# Contributing

## To release a new version

1. Update Gemfile if needed
2. `bundle update`
3. git tag
4. Push
5. Make GitHub release
